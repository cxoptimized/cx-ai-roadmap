const fs = require('fs');
const path = require('path');
const PDFDocument = require('pdfkit');
const { Configuration, OpenAIApi } = require('openai');

const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY
});
const openai = new OpenAIApi(configuration);

module.exports = async (req, res) => {
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Only POST requests allowed' });
  }

  try {
    const { companyName, industry, existingSystems, painPoints, goals, email } = req.body;

    const prompt = `Create an AI Integration Roadmap for a ${industry} company named ${companyName}.\n\nExisting Systems: ${existingSystems}\nPain Points: ${painPoints}\nGoals: ${goals}\n\nThe roadmap should include:\n- Quick Wins\n- Mid-Term Strategies\n- Long-Term AI Opportunities\n- Suggested Tools\n- Expected ROI`;

    const aiResponse = await openai.createChatCompletion({
      model: 'gpt-4',
      messages: [{ role: 'user', content: prompt }],
      temperature: 0.7
    });

    const roadmapText = aiResponse.data.choices[0].message.content;

    const fileName = `${companyName.replace(/\s+/g, '_')}_AI_Roadmap.pdf`;
    const filePath = path.join('/tmp', fileName);
    const doc = new PDFDocument();
    const writeStream = fs.createWriteStream(filePath);
    doc.pipe(writeStream);

    doc.image(path.join(__dirname, '../assets/fulllogo.jpg'), { width: 120 });
    doc.fontSize(20).fillColor('#6bd14b').text('CX Optimized – AI Integration Roadmap', { align: 'center' });
    doc.moveDown();
    doc.fontSize(12).fillColor('black').text(roadmapText, { align: 'left', lineGap: 6 });
    doc.end();

    await new Promise(resolve => writeStream.on('finish', resolve));
    const pdfBuffer = fs.readFileSync(filePath);

    res.setHeader('Content-disposition', `attachment; filename="${fileName}"`);
    res.setHeader('Content-Type', 'application/pdf');
    res.send(pdfBuffer);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Failed to generate PDF' });
  }
};