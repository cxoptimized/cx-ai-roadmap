# CX Optimized AI Integration Tool

This tool receives business information and generates a branded PDF AI Integration Roadmap using GPT-4.

## Usage
Deploy on Vercel. Make sure to set `OPENAI_API_KEY` in the environment variables.