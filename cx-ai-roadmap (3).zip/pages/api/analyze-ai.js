
import { Configuration, OpenAIApi } from 'openai';

const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY,
});
const openai = new OpenAIApi(configuration);

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();

  const { companyName, industry, existingSystems, painPoints, goals } = req.body;

  try {
    const prompt = `Create an AI roadmap for a ${industry} company called ${companyName}. Existing Systems: ${existingSystems}. Pain Points: ${painPoints}. Goals: ${goals}.`;
    const aiResponse = await openai.createChatCompletion({
      model: 'gpt-4',
      messages: [{ role: 'user', content: prompt }],
      temperature: 0.7
    });

    const roadmapText = aiResponse.data.choices[0].message.content;
    res.status(200).json({ roadmap: roadmapText });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
}
