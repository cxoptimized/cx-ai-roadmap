
import Head from 'next/head';

export default function Home() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'Arial' }}>
      <Head>
        <title>CX Optimized - AI Integration Tool</title>
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <h1>Welcome to CX Optimized AI Integration Tool</h1>
      <p>This is a placeholder. Connect your frontend UI here.</p>
    </div>
  );
}
